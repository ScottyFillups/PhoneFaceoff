<?php
	/**
	 * Dummy file: gets data and echos it back
	 * 
	 * @author Philip Scott
	 * @date 2016-05-20
	 * @request		search		search term
	 * @echo 		$search		search term
	 */

	$search = $_REQUEST["search"];
	echo $search;
?>