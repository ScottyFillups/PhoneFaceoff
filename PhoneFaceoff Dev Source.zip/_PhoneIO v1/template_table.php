<table>
	<tr>
		<th colspan="3">Network</th>
	</tr>
	<tr>
		<td>Technology</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>2G bands</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>3G Network</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>4G Network</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Speed</td>
		<td>data</td
		><td>data</td>
	</tr>
	<tr>
		<td>GPRS</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>EDGE</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Launch</th>
	</tr>
	<tr>
		<td>Announced</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Status</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Body</th>
	</tr>
	<tr>
		<td>Dimensions</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Weight</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>SIM</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Display</th>
	</tr>
	<tr>
		<td>Type</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Size</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Resolution</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Multitouch</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Protection</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Platform</th>
	</tr>
	<tr>
		<td>OS</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Chipset</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>CPU</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>GPU</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Memory</th>
	</tr>
	<tr>
		<td>Card slot</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Internal</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Camera</th>
	</tr>
	<tr>
		<td>Primary</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Features</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Video</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Secondary</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
		
	<tr>
		<th colspan="3">Sound</th>
	</tr>
	<tr>
		<td>Alert types</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Loudspeaker</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>3.5mm jack</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Comm</th>
	</tr>
	<tr>
		<td>WLAN</td>
		<td>dataawdwadwadwwad awdaawdwadawwad</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Bluetooth</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>GPS</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>NFC</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Infrared port</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Radio</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>USB</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Features</th>
	</tr>
	<tr>
		<td>Sensors</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Messaging</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Browser</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Java</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Battery</th>
	</tr>
	<tr>
		<td>Type</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Stand-by</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Talk time</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>Music play</td>
		<td>data</td>
		<td>data</td>
	</tr>
	
	
	
	<tr>
		<th colspan="3">Misc</th>
	</tr>
	<tr>
		<td>Colors</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>SAR US</td>
		<td>data</td>
		<td>data</td>
	</tr>
	<tr>
		<td>SAR EU</td>
		<td>data</td>
		<td>data</td>
	</tr>
</table>