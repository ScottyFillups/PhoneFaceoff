$(document).ready( function() {
	var viewport = new Viewport();
	var table = new Table("#phone-table");
	var image = new ImageListener();
	
	viewport.update(0,0);
});